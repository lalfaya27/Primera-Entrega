function saludar () {
confirm ("Bienvenida!\n Esta ingresando a e-mercado");
}

saludar ();